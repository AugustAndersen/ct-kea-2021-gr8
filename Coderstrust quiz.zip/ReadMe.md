1. User skal have downloadet MYSQL workbench og community server.
2. User skal have downloadet Zip filen "Coderstrust" med DDL og DML commands.
3. Efter DDL og DML commands er blevet kørt, skal User benytte SQL-Commanden "Drop database if exists coderstrustfinal;".
4. Programmet udføres via SQL Community server.
5. SQL-Commands er udført på MAC OS og Windows 7, 10.
